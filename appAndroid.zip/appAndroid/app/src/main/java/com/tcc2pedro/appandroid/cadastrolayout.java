package com.tcc2pedro.appandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

import static java.lang.Thread.sleep;

public class cadastrolayout extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);
    }

    public void proxgravar(View v) throws JSONException, InterruptedException, IOException {
        startActivity(new Intent(this, com.tcc2pedro.appandroid.gravacao.class));
        final TextView tv_result = (TextView) findViewById(R.id.tv_result);
        String FILENAME = "storage.json";
        JSONObject object = new JSONObject();

        EditText edit = (EditText)findViewById(R.id.editText1);
        String result = edit.getText().toString();
        object.put("nome", result);

        EditText edit2 = (EditText)findViewById(R.id.editText2);
        String result2 = edit2.getText().toString();
        object.put("idade", result2);

        EditText edit3 = (EditText)findViewById(R.id.editText3);
        String result3 = edit3.getText().toString();
        object.put("prof", result3);

        //////Radio 1 /////////////////
        final RadioGroup radioGroup1 = (RadioGroup) findViewById(R.id.radioGroup1);
        int selectedRadioButtonID = radioGroup1.getCheckedRadioButtonId();
        // If nothing is selected from Radio Group, then it return -1
        if (selectedRadioButtonID != -1) {

            RadioButton selectedRadioButton = (RadioButton) findViewById(selectedRadioButtonID);
            String selectedRadioButtonText = selectedRadioButton.getText().toString();
            object.put("sexo", selectedRadioButtonText);
            System.out.println(selectedRadioButtonText);
            sleep(50);

        }
        else{
            object.put("sexo", "none");
        }

        //////Radio 2 /////////////////
        final RadioGroup radioGroup2 = (RadioGroup) findViewById(R.id.radioGroup2);
        int selectedRadioButtonID2 = radioGroup2.getCheckedRadioButtonId();
        // If nothing is selected from Radio Group, then it return -1
        if (selectedRadioButtonID2 != -1) {

            RadioButton selectedRadioButton2 = (RadioButton) findViewById(selectedRadioButtonID2);
            String selectedRadioButtonText2 = selectedRadioButton2.getText().toString();
            object.put("roco", selectedRadioButtonText2);
            System.out.println(selectedRadioButtonText2);
            sleep(50);
        }
        else{
            object.put("roco", "none");
        }

        //////Radio 3 /////////////////
        final RadioGroup radioGroup3 = (RadioGroup) findViewById(R.id.radioGroup3);
        int selectedRadioButtonID3 = radioGroup3.getCheckedRadioButtonId();
        // If nothing is selected from Radio Group, then it return -1
        if (selectedRadioButtonID3 != -1) {

            RadioButton selectedRadioButton3 = (RadioButton) findViewById(selectedRadioButtonID3);
            String selectedRadioButtonText3 = selectedRadioButton3.getText().toString();
            object.put("seca", selectedRadioButtonText3);
            System.out.println(selectedRadioButtonText3);
            sleep(50);
        }
        else{
            object.put("seca", "none");
        }

        //////Radio 4 /////////////////
        final RadioGroup radioGroup4 = (RadioGroup) findViewById(R.id.radioGroup4);
        int selectedRadioButtonID4 = radioGroup4.getCheckedRadioButtonId();
        // If nothing is selected from Radio Group, then it return -1
        if (selectedRadioButtonID4 != -1) {

            RadioButton selectedRadioButton4 = (RadioButton) findViewById(selectedRadioButtonID4);
        String selectedRadioButtonText4 = selectedRadioButton4.getText().toString();
            object.put("dificuldade", selectedRadioButtonText4);
        System.out.println(selectedRadioButtonText4);
        sleep(50);
    }
        else{
            object.put("dificuldade", "none");
    }

        //////Radio 5 /////////////////
        final RadioGroup radioGroup5 = (RadioGroup) findViewById(R.id.radioGroup5);
        int selectedRadioButtonID5 = radioGroup5.getCheckedRadioButtonId();
        // If nothing is selected from Radio Group, then it return -1
        if (selectedRadioButtonID5 != -1) {

            RadioButton selectedRadioButton5 = (RadioButton) findViewById(selectedRadioButtonID5);
            String selectedRadioButtonText5 = selectedRadioButton5.getText().toString();
            object.put("dor", selectedRadioButtonText5);
            System.out.println(selectedRadioButtonText5);
            sleep(50);

        }
        else{
            tv_result.setText("Nothing selected from Radio Group.");
        }

        try {
            Writer output;
            File file = new File("/sdcard/cadastro.json");
            output = new BufferedWriter(new FileWriter(file));
            output.write(object.toString());
            output.close();
            Toast.makeText(getApplicationContext(), "Informações Salvas", Toast.LENGTH_LONG).show();

        } catch (Exception e) {
            Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }



}
