
function mudaFoto(foto)
    {
    document.getElementById("icone").src = foto;
    }

function myFunction(){
    window.open('static/download/tcc.pdf', "_blank")
    
}


